# Sagar KC — Data Analyst Portfolio

Open `index.html` in a browser to view the portfolio.

The site is responsive and includes:
- Data Analyst / Business Intelligence hero section
- Skills and toolkit
- Filterable projects
- Experience, education and certifications
- Contact section
- Light/dark theme toggle
- Resume download

Replace the project visual placeholders with your actual dashboard screenshots when ready.
